'use strict';

var uuid = require('node-uuid');
var bodyParser = require('body-parser');
var http = require('http');

exports.sessionPOST = function(req, res, next) {
  res.setHeader('Content-Type', 'application/json');
  var sessionId = uuid.v1();
  res.end(JSON.stringify(sessionId))
}

exports.sessionSessionIdDELETE = function(req, res, next) {
  
  res.end(JSON.stringify(req.params.sessionId+': delete session'));
}

exports.sessionSessionIdKeyDELETE = function(req, res, next) {
  res.end(JSON.stringify(req.params.sessionId+'/'+req.params.key)+': delete key');
}

exports.sessionSessionIdKeyGET = function(req, res, next) {
  /**
   * parameters expected in the args:
  * sessionId (String)
  * key (String)
  **/
  
  
  res.end(JSON.stringify(req.params.sessionId+'/'+req.params.key)+': get');
}

exports.sessionSessionIdKeyPUT = function(args, res, next) {
  /**
   * parameters expected in the args:
  * sessionId (String)
  * key (String)
  * value (String)
  **/
  // no response value expected for this operation
  
  console.log(args.sessionId);
  console.log(args.key);
  console.log(args.value);
  
  var data = args.value.value;
  
  var reqUrl = '/v1/kv/'+args.sessionId.value+'/'+args.key.value+'?dc=nyc3';
  var urlwithHost = 'http://demo.consul.io'+reqUrl;
  console.log(urlwithHost);
  
  var options = {
	  host: 'demo.consul.io',
	  port: '80',
	  path: reqUrl,
	  method: 'PUT',
	  headers: {
		'Content-Type': 'text/plain; charset=utf-8',
		'Content-Length': data.length
	  }
  }

    var options2 = {
	  host: 'np1prxy801.corp.halliburton.com',
	  port: '80',
	  path: urlwithHost,
	  method: 'PUT',
	  headers: {
		'Content-Type': 'text/plain; charset=utf-8'  
	  }
  }

  var response_data = '';
  var postReq = http.request(options2, function(postRes) {
		postRes.setEncoding('utf8');
		postRes.on('data', function(chunk) {
			response_data += chunk;
		});
		postRes.on('end', function() {
			//console.log(JSON.parse(response_data));
		});
  });
  
  postReq.write(data);
  console.log(response_data);
  postReq.end(JSON.stringify("end"));
  
  //res.end(JSON.stringify(args.sessionId.value+'/'+args.key.value)+': put');
}

